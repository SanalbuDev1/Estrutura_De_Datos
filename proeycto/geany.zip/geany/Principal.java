public class Principal {
    
    public static void main(String[] args) {
        
        pacmanN ob = new pacmanN();
        
        
        
    }
    
}
